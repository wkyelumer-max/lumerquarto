This directory is reserved for translation files.
