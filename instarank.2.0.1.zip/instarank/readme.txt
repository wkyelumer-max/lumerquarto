=== InstaRank ===
Contributors: instarank
Tags: seo, optimization, meta tags, search engine, ai
Requires at least: 5.6
Tested up to: 6.9
Stable tag: 2.0.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered SEO optimization and programmatic content for WordPress. Auto-apply improvements and sync custom post types.

== Description ==

InstaRank is the official WordPress plugin for the InstaRank platform. It enables seamless integration between your WordPress site and InstaRank's AI-powered SEO optimization engine and programmatic SEO tools.

= Key Features =

* **Easy Connection**: Connect your WordPress site to InstaRank with a simple API key or one-click OAuth
* **AI-Powered SEO**: Receive intelligent SEO recommendations powered by advanced AI
* **Programmatic SEO**: Create and sync custom post types between InstaRank and WordPress
* **Page Builder Templates**: Import and manage templates from Elementor, Kadence, Divi, and more
* **Bidirectional Sync**: Sync post types from InstaRank to WordPress and vice versa
* **Custom Post Type Management**: Register, update, and manage custom post types directly from InstaRank
* **Review Before Apply**: Review all suggested changes before they're applied to your site
* **Safe Rollback**: Easily rollback any changes if needed
* **Change History**: Track all SEO modifications with a complete audit log
* **SEO Plugin Detection**: Automatically detects and integrates with popular SEO plugins like Yoast SEO, Rank Math, and All in One SEO
* **Flexible Approval**: Choose between manual review or automatic approval of changes
* **WordPress Coding Standards**: Fully compliant with WordPress Plugin Check requirements

= Supported Change Types =

* Meta titles and descriptions
* Open Graph tags (og:title, og:description, og:image)
* Post content optimization
* Image alt text optimization
* Canonical URLs
* Focus keywords
* Robots meta tags
* Post titles
* Schema markup generation
* Structured data implementation

= How It Works =

**Easy OAuth Connection:**

1. Install and activate the plugin
2. Click "Connect with InstaRank" button in WordPress admin
3. Sign in to your InstaRank account (popup window)
4. Select the project to connect
5. Done! Your WordPress site is connected

**Or use the manual API key method:**

1. Install and activate the plugin
2. Copy the generated API key from the plugin dashboard
3. Connect your site from your InstaRank account at instarank.com
4. InstaRank analyzes your site and generates SEO improvements
5. Review and approve changes from your WordPress dashboard
6. Changes are applied automatically to your content

= Privacy & Data =

This plugin communicates with the InstaRank platform (https://instarank.com) to:

* Send site information and content for SEO analysis
* Receive SEO optimization recommendations
* Sync change status and results
* Import and manage page builder templates

For more information, see our [Privacy Policy](https://www.instarank.com/privacy-policy) and [Terms of Service](https://www.instarank.com/terms-conditions).

== Installation ==

= Automatic Installation =

1. Log in to your WordPress admin panel
2. Navigate to Plugins > Add New
3. Search for "InstaRank"
4. Click "Install Now" and then "Activate"

= Manual Installation =

1. Download the plugin ZIP file
2. Log in to your WordPress admin panel
3. Navigate to Plugins > Add New > Upload Plugin
4. Choose the downloaded ZIP file and click "Install Now"
5. Activate the plugin

= After Installation =

1. Go to InstaRank in your WordPress admin menu
2. Click "Connect with InstaRank" for one-click setup
3. Or copy the API key and add your site from InstaRank.com
4. Start receiving AI-powered SEO recommendations!

== Frequently Asked Questions ==

= Where is the Programmatic SEO menu? =

Starting in version 2.0, Programmatic SEO features are managed through the InstaRank SaaS platform at https://app.instarank.com. This provides better features, easier management, and a more powerful interface. Your WordPress plugin continues to handle page syncing automatically.

To use Programmatic SEO:
1. Log in to https://app.instarank.com
2. Navigate to your project
3. Go to "Programmatic SEO" section
4. Use the Generation Wizard to create pages
5. Pages sync automatically to your WordPress site

= Do I need an InstaRank account? =

Yes, you need an active InstaRank account to use this plugin. Sign up at https://instarank.com

= Is this plugin free? =

The plugin itself is free, but it requires an InstaRank subscription to function. Visit https://instarank.com/pricing for subscription details.

= Which SEO plugins are compatible? =

InstaRank works with:

* Yoast SEO
* Rank Math
* All in One SEO Pack
* The SEO Framework
* SEOPress
* Or as a standalone SEO solution

= Which page builders are supported? =

InstaRank can import and manage templates from:

* Elementor
* Kadence Blocks
* Beaver Builder
* Divi Builder
* Bricks Builder
* Gutenberg Reusable Blocks
* GenerateBlocks

= Can I review changes before they're applied? =

Yes! By default, all changes require manual approval. You can optionally enable auto-approval in the settings.

= Can I rollback changes? =

Absolutely. Every change is tracked and can be rolled back with a single click from the Pending Changes page.

= How is my data used? =

Your site content is sent to InstaRank's servers for SEO analysis. We do not share your data with third parties. See our [Privacy Policy](https://www.instarank.com/privacy-policy).

= What happens if I deactivate the plugin? =

All SEO changes that were applied remain on your site. The plugin will stop communicating with InstaRank, and you won't receive new recommendations.

= Where can I get support? =

For support, visit https://instarank.com/support or email support@instarank.com

== Screenshots ==

1. Dashboard showing connection status and API key
2. Pending Changes page with approval options
3. Settings page for configuring plugin behavior
4. Change history with rollback options

== Changelog ==

= 2.0.1 =
* Fix: Enhanced image import reliability for Kadence blocks with dynamic content
* Fix: Block comment rendering now properly handles HTML-encoded sequences
* Fix: Prevent content corruption by avoiding unescaping in programmatic SEO sync
* Fix: Updated dashboard programmatic SEO links to point to SaaS platform
* Feature: ACF (Advanced Custom Fields) field mapping support for programmatic SEO
* Feature: Custom fields tab for dataset-template field mappings
* Feature: Field-only generation mode and stats API endpoint
* Enhancement: Links now open in new tab for better user experience
* Enhancement: Dynamic URL generation based on project slug
* Enhancement: Improved content processing for Kadence blocks with HTML formatting
* Refactor: Removed deprecated location generator class

= 2.0.0 =
* BREAKING CHANGE: Programmatic SEO UI removed from WordPress plugin
* Feature: All Programmatic SEO features now managed via InstaRank SaaS platform at app.instarank.com
* Enhancement: Better UX with more powerful Generation Wizard in SaaS
* Enhancement: AI-powered field auto-mapping in SaaS
* Enhancement: Advanced spintax tools with quality analyzer in SaaS
* Enhancement: Flexible sync modes (create, update, smart sync) in SaaS
* Enhancement: Auto image import to WordPress Media Library
* Enhancement: Batch operations for bulk actions
* Technical: Kept all backend API endpoints functional for SaaS integration
* Technical: Kept spintax engine for local content processing
* Technical: Removed 7 admin UI files (programmatic-seo.php and tab files)
* Migration: Log in to app.instarank.com to access programmatic SEO features
* Compatibility: Generated pages remain in WordPress - no data loss

= 1.5.9 =
* Fix: Resolved image alt attribute replacement in programmatic SEO sync
* Fix: Enhanced WordPress plugin spintax engine to handle bare HTML attributes (src="field", alt="field", title="field")
* Fix: Enhanced SaaS template parser to detect and replace alt/title/href attributes
* Fix: Fixed sync-single route removing incorrect replaceTemplateFields() call that corrupted already-generated content
* Enhancement: Added networking fix script to update localhost URLs to 127.0.0.1 for ECONNREFUSED errors
* Enhancement: Enhanced field detector to identify bare attribute patterns
* Compatibility: Tested with WordPress 6.9
* Code Quality: Improved attribute replacement logic to preserve final values during sync

= 1.5.8 =
* Performance: Fixed memory exhaustion on large WordPress sites (1000+ pages)
* Performance: Reduced crawl batch size from 200 to 25 pages for better memory management
* Performance: Added aggressive memory cleanup after processing each page
* Compatibility: Improved support for hosts with limited PHP memory (16MB-128MB)
* Fix: Resolved "Allowed memory size exhausted" errors during crawl operations

= 1.5.7 =
* Enhancement: Improved Knowledge Base generation with comprehensive data extraction
* Enhancement: Batch processing support for large sites with 1000+ pages
* Enhancement: Extended Knowledge Base fields including testimonials, case studies, pricing, and more
* Enhancement: Generation history tracking to view past Knowledge Base generations
* Fix: Resolved database column reference errors in crawl queries

= 1.5.6 =
* Feature: Added crawl-data REST API endpoints for WordPress-based crawling
* Feature: New `/crawl-data` endpoint returns paginated SEO data for all published pages
* Feature: New `/crawl-data/page` endpoint returns detailed SEO data for a single page by ID or URL
* Enhancement: Crawl endpoints return full HTML content, meta tags, headings, links, images, and schema data
* Enhancement: Support for pagination with limit/offset parameters (max 100 items per request)
* Enhancement: Automatic detection of schema data from Yoast, RankMath, AIOSEO, and InstaRank
* Enhancement: Extracts internal/external links with anchor text analysis
* Enhancement: Returns image data including src, alt text, and dimensions

= 1.5.5 =
* Performance: Added object caching for custom field matching queries to reduce database load
* Compliance: Fixed WordPress Plugin Check slow_db_query warning with phpcs:ignore annotation

= 1.5.4 =
* Enhancement: Replaced browser confirm() dialogs with custom modal system for better UX
* Enhancement: Added styled confirmation modals for disconnect, clear history, rollback, and other actions
* Enhancement: Modal system supports warning, danger, info, and success types with appropriate styling
* Enhancement: Added clear programmatic SEO data on disconnect (clears datasets, field mappings, template configs)
* Fix: Stale programmatic SEO statistics now properly cleared when disconnecting WordPress site

= 1.5.3 =
* Feature: Enhanced programmatic SEO sync with real-time progress modal
* Feature: Auto-import external images to WordPress Media Library during page publishing
* Feature: CORS support for cross-origin WordPress API requests
* Enhancement: Improved Classic Editor integration with better meta box handling
* Enhancement: Better sync status tracking and error reporting
* Enhancement: Added image import options to generation settings

= 1.5.2 =
* Performance: Optimized Related Links internal linking for WordPress VIP compliance
* Performance: Replaced post__not_in with post-query filtering for better database performance on large sites
* Code Quality: Improved WP_Query usage following WordPress VIP best practices
* Reference: https://wpvip.com/documentation/performance-improvements-by-removing-usage-of-post__not_in/

= 1.5.1 =
* Feature: Added internationalization (i18n) support with 8 language translations
* Feature: New post type filter tabs on Templates page for easier navigation
* Feature: Added pagination to Templates page (25 items per page) for sites with thousands of templates
* Enhancement: Translations included: English, Spanish, French, German, Portuguese (Brazil), Italian, Dutch, Japanese, Chinese (Simplified)
* Enhancement: Post type column added to templates table for better organization
* Fix: Removed deprecated load_plugin_textdomain() call (WordPress 4.6+)
* Compliance: Fixed MissingTranslatorsComment warning for proper i18n format

= 1.5.0 =
* Feature: Template scanning now includes draft and private posts/pages (not just published)
* Feature: Improved template detection for page builder template libraries
* Enhancement: Added status field to all scanned templates for better visibility
* Enhancement: Added edit_url field to quickly access template editing
* Enhancement: Elementor templates now include draft, publish, and private statuses
* Enhancement: Beaver Builder templates now include draft, publish, and private statuses
* Enhancement: Divi Library layouts now include draft, publish, and private statuses
* Enhancement: Gutenberg reusable blocks now include draft, publish, and private statuses

= 1.4.9 =
* Feature: Added DELETE endpoint for custom post types via REST API
* Fix: Preserved Unicode escape sequences in Kadence block JSON (fixes corrupted button text)
* Fix: Replaced stripcslashes() with targeted escape handling to prevent block corruption

= 1.4.8 =
* Security: Fixed all WordPress Plugin Check warnings and errors
* Security: Added proper input sanitization with wp_unslash()
* Compliance: All global variables now use instarank_ prefix
* Compliance: Added phpcs:ignore comments for meta_query usage

= 1.4.7 =
* Fix: Resolved SQL LIKE wildcards warning by using prepared statement placeholders
* Enhancement: Replaced direct database queries with WordPress metadata API (get_post_meta)
* Performance: Added wp_cache implementation for Kadence metadata queries
* Code Quality: Removed error_log() debug statements from production code
* Compliance: Renamed array keys to avoid WordPress slow query detection false positives
* Compliance: Plugin now passes WordPress Plugin Check with zero errors or warnings
* Standards: Fully compliant with WordPress.org plugin repository coding standards

= 1.4.6 =
* Code Quality: Removed all development test files for production release
* Code Quality: Removed debug logging statements (error_log, file_put_contents) from production code
* Compliance: Cleaned up endpoints.php to meet WordPress coding standards
* Enhancement: Improved code quality for WordPress.org plugin directory standards
* Security: Removed test files with potential security issues

= 1.4.5 =
* Enhancement: Improved programmatic SEO image handling for Kadence Blocks
* Enhancement: Custom field sanitization now preserves hyphens in field names (e.g., h2-1-image)
* Enhancement: Better support for page builder dynamic images
* Enhancement: Optimized image upload and media library integration
* Fix: Resolved custom field name sanitization issue that affected Kadence dynamic images
* Fix: Improved custom field handling to support structured naming conventions

= 1.4.4 =
* Security: Fixed all Plugin Check warnings and errors
* Security: Added proper input sanitization throughout the plugin
* Security: Fixed unescaped database parameters with proper phpcs:ignore comments
* Performance: Added caching for frequently accessed database queries
* Enhancement: Improved WordPress coding standards compliance
* Fix: Corrected variable naming inconsistencies with instarank_ prefix
* Fix: Updated privacy policy and terms of service links
* Code Quality: Removed all debug statements from production code
* Code Quality: Added comprehensive phpcs:ignore comments where necessary
* Compliance: Plugin now passes WordPress Plugin Check with zero critical issues

= 1.4.3 =
* Fix: Resolved undefined variable warnings throughout the plugin
* Fix: Fixed disconnect functionality to properly persist state
* Fix: Corrected Pending Changes page display issues
* Enhancement: Increased PHP memory limits for larger plugin uploads
* Enhancement: Added proper connection status checks
* Enhancement: Improved error handling and user feedback
* UX: Better status messages and notifications
* Code Quality: Consistent variable prefixing with instarank_

= 1.4.2 =
* Feature: Added Kadence Blocks support for template scanning
* Feature: Scan and import Kadence Elements (kadence_element post type)
* Enhancement: Extended page builder detection to include Kadence Blocks
* Enhancement: Capture Kadence element metadata (type and placement)
* API: Enhanced templates/scan endpoint to include Kadence Elements

= 1.4.1 =
* Feature: Page Builder API - Detect and import templates from various page builders
* Feature: Support for Elementor, Beaver Builder, Divi, Bricks, and Gutenberg reusable blocks
* API: New endpoint for scanning existing templates across different builders
* Enhancement: Unified template management across multiple page builders

= 1.3.2 =
* Feature: Programmatic SEO - Create and register custom post types from InstaRank
* Feature: Bidirectional custom post type sync between InstaRank and WordPress
* Feature: Update custom post types created in InstaRank directly from the dashboard
* API: New POST endpoint to register custom post types from InstaRank
* API: New PUT endpoint to update existing custom post types
* API: Sync all WordPress post types to InstaRank with preserved metadata
* Enhancement: Auto-register stored custom post types on WordPress init
* Enhancement: Persistent storage of InstaRank-created post types across WordPress restarts
* Security: Validation to prevent external post types from being modified via API
* UX: Seamless integration for programmatic SEO workflows

= 1.2.4 =
* Fix: Corrected API URL to point to main app (https://instarank.com) instead of API subdomain
* Fix: OAuth connection now works properly with correct endpoint URLs
* Enhancement: Added clear documentation about API URL configuration

= 1.2.3 =
* Fix: Corrected text domain from 'instarank-seo' to 'instarank' for WordPress.org compliance
* Security: Added proper sanitization and unslashing for POST data
* Security: Added phpcs:ignore with explanation for already-escaped output
* Compliance: Fixed all Plugin Check errors for WordPress.org submission

= 1.2.2 =
* Fix: State synchronization bug - WordPress now properly detects when integration is disconnected from InstaRank dashboard
* Enhancement: Added server-side verification endpoint to check integration status
* Enhancement: "Check Status" button now verifies with InstaRank backend and clears stale connection state
* Security: Improved connection validation and cleanup
* UX: Better error messages when connection is removed from dashboard

= 1.2.1 =
* Feature: OAuth-style popup connection flow (connect with one click!)
* Feature: "Connect with InstaRank" button for easy setup
* Feature: Automatic project selection during connection
* Feature: Modern, redesigned admin dashboard with enhanced UI/UX
* Enhancement: Improved button styles with hover animations
* Enhancement: Better status badges with modern design
* Enhancement: Enhanced notification system with auto-dismiss
* Security: OAuth token-based authentication with 15-minute expiration
* Security: HTTPS enforcement for WordPress sites
* UX: Popup window auto-closes after successful connection
* UX: Real-time connection status updates

= 1.1.0 =
* Feature: Added support for post content updates (low_word_count fixes)
* Feature: Added bulk approve/reject API endpoint for external integrations
* Enhancement: Improved change type handling for all SEO optimization types
* API: New /changes/bulk endpoint for batch operations
* Compatibility: Full support for content length optimization

= 1.0.1 =
* Security: Fixed all output escaping issues for enhanced security
* Security: Added proper input sanitization with wp_unslash()
* Security: Sanitized all $_SERVER variable access
* Code Quality: Replaced date() with gmdate() for timezone-safe operations
* Code Quality: Removed debug error_log() calls from production code
* Code Quality: Added comprehensive PHPCS ignore comments for custom database tables
* Compliance: Updated to pass all WordPress.org Plugin Check requirements with zero errors
* Compliance: Shortened plugin description to meet 150 character limit
* Fix: Added missing languages directory referenced in plugin headers

= 1.0.0 =
* Initial release
* WordPress site connection via API key
* SEO change review and approval system
* Automatic detection of popular SEO plugins
* Change rollback functionality
* Comprehensive change history and audit log
* Support for meta tags, Open Graph, and content optimization
* Settings for auto-approval and change type filtering

== Upgrade Notice ==

= 2.0.0 =
BREAKING CHANGE: Programmatic SEO UI moved to InstaRank SaaS platform (app.instarank.com). Log in to app.instarank.com to access the new Generation Wizard with enhanced features. All backend functionality preserved - pages sync automatically.

= 1.4.4 =
Important security and performance update! Fixes all Plugin Check warnings, improves WordPress coding standards compliance, and enhances performance with query caching. Recommended for all users.

= 1.4.3 =
Critical bug fixes! Resolves undefined variable warnings, fixes disconnect functionality, and improves Pending Changes display. Recommended for all users.

= 1.3.2 =
Major update! Programmatic SEO features - Create and sync custom post types between InstaRank and WordPress. Bidirectional sync support and seamless integration for programmatic content workflows.

= 1.2.2 =
Critical bug fix! Resolves state synchronization issue where WordPress showed "connected" even after disconnecting from InstaRank dashboard.

= 1.2.1 =
Major update! New one-click OAuth connection flow makes setup easier than ever. Modern UI redesign with enhanced UX.

= 1.1.0 =
New features: Post content optimization support and bulk operations API.

= 1.0.0 =
Initial release of InstaRank plugin.

== Third Party Services ==

This plugin connects to the InstaRank service (https://instarank.com) to provide its functionality. By using this plugin, you agree to InstaRank's:

* Terms of Service: https://www.instarank.com/terms-conditions
* Privacy Policy: https://www.instarank.com/privacy-policy

Data transmitted to InstaRank includes:

* Site URL and basic WordPress information
* Published posts and pages
* Current SEO meta data
* Plugin activation/deactivation events
* Page builder templates and configurations